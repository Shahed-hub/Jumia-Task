package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class baseClass {
    System.setProperty("webdriver.chrome.driver", "/home/user/IdeaProjects/CucumberTask");

    public WebDriver driver = new ChromeDriver();
}
