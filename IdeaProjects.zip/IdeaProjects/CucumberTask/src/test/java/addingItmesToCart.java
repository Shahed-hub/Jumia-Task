import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class addingItmesToCart {
    @And("I hover on Supermarket then click on bakery")
    public void hoverOnSupermarketAndClickBakery() {

    }

    @And("I add two items.feature to my cart")
    public void addItemsToCart() {

    }

    @Then("I verify that the item is added to the cart successfully")
    public void verifyItemAddedToCart() {

    }

    @Then("I verify that the subtotal is calculated correctly")
    public void verifySubtotal() {

    }
}
