package Pages;

public class supermarketAndBakeryPage {

}
