import Pages.signUpPage;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import java.util.List;
import java.util.Map;

public class signUp extends signUpPage  {



    @DataTableType
    public signUpPage.RegistrationInfo convert(Map<String, String> entry) {
        return new signUpPage.RegistrationInfo(entry.get("First Name"), entry.get("Last Name"),
                entry.get("Email"), entry.get("Password"), entry.get("Mobile Number"));
    }

    @Given("I am on the Jumia Egypt registration page")
    public void navigateToRegistrationPage() {
        driver.get("https://www.jumia.com.eg/customer/account/create/");
    }

    @When("I enter my registration information as follows:")
    public void enterRegistrationInfo(List<signUpPage.RegistrationInfo> registrationInfoList) {
        signUpPage.RegistrationInfo registrationInfo = registrationInfoList.get(0);

        emailField.sendKeys(registrationInfo.getEmail());
        submit.click();
        passwordField.sendKeys(registrationInfo.getPassword());
        reTypePasswordField.sendKeys(registrationInfo.getPassword());
        submit.click();
        firstNameField.sendKeys(registrationInfo.getFirstName());
        lastNameField.sendKeys(registrationInfo.getLastName());
        mobileNumber.sendKeys(registrationInfo.getMobileNumber());
        submit.click();

    }

    @When("I submit the registration form")
    public void submitRegistrationForm() {
        submitButton.click();
    }

    @Then("I should be successfully registered and logged in")
    public void verifySuccessfulRegistration() {
        String actualMessage = welcomeMessage.getText();
        Assert.assertEquals(expectedMessage, actualMessage);
    }




}
