import Pages.homePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class login extends homePage {


    @Given("I'm on Jumia main page")
    public void navigateToJumiaURL() {driver.get("https://www.jumia.com.eg/customer/account/create/");
    }

    @When("I click on the Account -> Login link")
    public void clickToLogin() {
        accountBtn.click();
        myAccountBtn.click();
    }

    @And("I log in using my account credentials")
    public void loginWithCredentials() {
         email.sendKeys("shahed.ibrahim.abdou10@gmail.com");
         continueBtn.click();
         password.sendKeys("01112761638");
         loginBtn.click();
    }

}
