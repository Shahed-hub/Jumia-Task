package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class homePage extends baseClass {


    protected WebElement accountBtn = driver.findElement(By.id("trig -df -i-ctr -fs16"));
    protected WebElement myAccountBtn = driver.findElement(By.xpath("//*[contains(text(),'My Account')]"));

    protected WebElement email = driver.findElement(By.id("input_identifierValue"));
    protected WebElement continueBtn = driver.findElement(By.className("mdc-button__touch"));
    protected WebElement password = driver.findElement(By.name("password"));
    protected WebElement loginBtn = driver.findElement(By.className("mdc-button__touch"));



}
