plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testImplementation ("io.cucumber:cucumber-java:6.1.1")
    testImplementation ("org.testng:testng:7.7.0")
    implementation ("com.google.guava:guava:31.0.1-jre")
    implementation ("org.seleniumhq.selenium:selenium-java:4.4.0")
    implementation ("io.github.bonigarcia:webdrivermanager:5.3.0")
    implementation ("org.seleniumhq.selenium:selenium-java:3.141.59")

    testImplementation ("org.junit.jupiter:junit-jupiter-api:5.8.1")
    testRuntimeOnly ("org.junit.jupiter:junit-jupiter-engine:5.8.1")

    testImplementation ("junit:junit:4.12")
    implementation ("junit:junit:4.12")

}

tasks.test {
    useJUnitPlatform()
}
