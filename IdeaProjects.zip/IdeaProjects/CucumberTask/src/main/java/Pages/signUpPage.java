package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class signUpPage extends baseClass {



     protected WebElement emailField = driver.findElement(By.id("input_identifierValue"));
    protected WebElement submit = driver.findElement(By.className("mdc-button__touch"));
    protected WebElement passwordField = driver.findElement(By.name("password"));
    protected WebElement reTypePasswordField = driver.findElement(By.xpath("//input[@autocomplete='confirm-password']"));
    protected WebElement firstNameField = driver.findElement(By.id("input_first_name"));
    protected WebElement lastNameField = driver.findElement(By.id("input_last_name"));
    protected WebElement mobileNumber = driver.findElement(By.name("phone[number]"));
    protected WebElement submitButton = driver.findElement(By.id("register-btn"));
    protected WebElement welcomeMessage = driver.findElement(By.xpath("//div[@class='welcome-message']"));
    protected String expectedMessage = "Welcome, Shahd!";


    public static class RegistrationInfo {
        private final String firstName;
        private final String lastName;
        private final String email;
        private final String password;

        private final String mobileNumber;

        public RegistrationInfo(String firstName, String lastName, String email, String password, String mobileNumber) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.password = password;
            this.mobileNumber = mobileNumber;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }

        public String getMobileNumber() {
            return mobileNumber;
        }
    }

}
