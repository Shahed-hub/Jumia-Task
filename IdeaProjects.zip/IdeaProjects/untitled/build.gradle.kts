plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testCompile group: 'info.cukes', name: 'cucumber-junit', version: '1.1.7'
    testCompile group: 'info.cukes', name: 'cucumber-core', version: '1.1.7'
    testCompile group: 'info.cukes', name: 'cucumber-java', version: '1.1.7'
}

tasks.test {
    useJUnitPlatform()
}